# Source content
This folder should contain only hpp/cpp files of your implementation. 
You can also place hpp files in a separate directory `include `.

You can create a summary of files here. It might be useful to describe 
file relations, and brief summary of their content.
